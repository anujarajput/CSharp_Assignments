﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class Grade
    {
        static void Main()
        {
            Console.WriteLine("Please enter your percentage:");
            int perc = Convert.ToInt32(Console.ReadLine());

            if(perc <= 30)
            {
                Console.WriteLine("Grage for {0}% : Fail", perc);
            }
            else if(perc >30 && perc <= 60)
            {
                Console.WriteLine("Grage for {0}% : Pass", perc);
            }else if(perc >60 && perc <= 75)
            {
                Console.WriteLine("Grage for {0}% : First Class", perc);
            }else if(perc > 75)
            {
                Console.WriteLine("Grage for {0}% : First Class with Distinction", perc);
            }
          
            Console.ReadLine();
        }
    }
}
