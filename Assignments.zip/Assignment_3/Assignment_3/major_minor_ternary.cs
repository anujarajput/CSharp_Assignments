﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class major_minor_ternary
    {
        static void Main()
        {
            Console.WriteLine("Please enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());

            var res = age <= 18 ? "Minor Person" : "Major Person";

            Console.WriteLine(res);

            Console.ReadLine();
        }
    }
}
