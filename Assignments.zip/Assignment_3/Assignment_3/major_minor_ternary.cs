﻿using System;

namespace Assignment_3
{
    class major_minor_ternary
    {
        static void Main()
        {
            //ternary operator Demo

            Console.WriteLine("Please enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());

            var res = age <= 18 ? "Minor Person" : "Major Person"; //use of ternary operators

            Console.WriteLine(res);

            Console.ReadLine();
        }
    }
}
