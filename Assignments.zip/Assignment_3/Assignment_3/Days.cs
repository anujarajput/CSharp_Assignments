﻿using System;

namespace Assignment_3
{
    class Days
    {
        
        static void Main()
        {
            //Switch case Demo
            
            Console.WriteLine("Enter number for day:");
            int day = Convert.ToInt32(Console.ReadLine());

            switch (day)
            {
                case 1:
                    Console.WriteLine("{0}:Monday",day);
                    break;
                case 2:
                    Console.WriteLine("{0}:Tuesday",day);
                    break;
                case 3:
                    Console.WriteLine("{0}:Wensday",day);
                    break;
                case 4:
                    Console.WriteLine("{0}:Thrusday",day);
                    break;
                case 5:
                    Console.WriteLine("{0}:Friday",day);
                    break;
                case 6:
                    Console.WriteLine("{0}:Saturday",day);
                    break;
                case 7:
                    Console.WriteLine("{0}:Sunday",day);
                    break;
                default:
                    Console.WriteLine("Invalid Choice...");
                    break;
            }

            Console.ReadLine();
        }
    }
}
