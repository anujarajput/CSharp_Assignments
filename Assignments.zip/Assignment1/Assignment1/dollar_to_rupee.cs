﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class dollar_to_rupee
    {

        static void Main()
        {
            Console.WriteLine("Enter dollar value :");
            double dolr = Convert.ToDouble(Console.ReadLine());
            
            int rs = Convert.ToInt32(71.05*dolr);//typecasting of double to int

            Console.WriteLine("$ {0} = RS {1}", dolr, rs);

            Console.ReadLine();

        }
      
    }
}
