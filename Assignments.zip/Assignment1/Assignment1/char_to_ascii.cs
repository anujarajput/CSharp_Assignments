﻿using System;

namespace Assignment1
{
    class char_to_ascii
    {
        static void Main()
        {
            Console.WriteLine("Enter character :");
            char chr = Convert.ToChar(Console.ReadLine());
            
            int ascii = chr;//impicite type conversion of char to int

            Console.WriteLine("ASCII code for character {0} = {1}", chr, ascii);

            Console.ReadLine();
        }
    }
}
