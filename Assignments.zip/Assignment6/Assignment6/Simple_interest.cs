﻿using System;

namespace Assignment6
{
    class Simple_interest
    {
        //Program to calculate Simple Interest 

        static void Main()
        {
            Console.WriteLine("Please enter Principal(in RS):");
            int p = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter Number of time period(in years):");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter Rate of interest(in %):");
            int r = Convert.ToInt32(Console.ReadLine());

            Calc_interest(p, n, r); //pasing Principal, time and rate of interest to function

            Console.ReadLine();

        }
        /// <summary>
        /// Calculating simple interest
        /// </summary>
        public static void Calc_interest(int p, int n, int r)
        {
            int total_int = (p * n * r) / 100;

            Console.WriteLine($"Simple Interest for Amount RS {p} for {n} years on {r}% interest : {total_int}");

            Console.ReadLine();
        }
    }
}
