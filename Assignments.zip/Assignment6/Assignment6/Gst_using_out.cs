﻿using System;

namespace Assignment6
{
    class Gst_using_out
    {
        static void Main()
        {
            Console.WriteLine("Please enter Product Amount");
            double prod_amount = Convert.ToInt32(Console.ReadLine());

            double payable_amount;

            Calc_GST(out payable_amount, prod_amount);

            Console.WriteLine($"Payable GST amount on your Product:{payable_amount}");

            Console.ReadLine();

        }

        static double Calc_GST(out double payable_amount, double prod_amount, double gst_perc=1)
        {
            double gst_amount = prod_amount * (gst_perc / 100);

            payable_amount = gst_amount + prod_amount;

            return payable_amount;
        }
    }
}
