﻿using System;

namespace Assignment6
{
    class Factorial_fun
    {
        static void Main()
        {
            Console.WriteLine("Please enter the number for factorial:");
            int num = Convert.ToInt32(Console.ReadLine());
            Get_factorial(num);


            Console.ReadLine();
        }
        public static void Get_factorial(int num)
        {
            int fact = 1;
            for(int i=1; i<=num; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine($"Factorial: {fact}");
        }
    }
}
