﻿using System;

namespace Assignment6
{
    class Factorial_fun
    {
        //Program to print factorial of given number.

        static void Main()
        {
            Console.WriteLine("Please enter the number for factorial:"); //taking input from user
            int num = Convert.ToInt32(Console.ReadLine());
            Get_factorial(num);


            Console.ReadLine();
        }
        public static void Get_factorial(int num)
        {
            int fact = 1;
            for(int i=1; i<=num; i++)
            {
                fact = fact * i; //calculating factorial
            }
            Console.WriteLine($"Factorial: {fact}");
        }
    }
}
