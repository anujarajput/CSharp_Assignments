﻿using System;

namespace Assignment6
{
    class Search_jogged_array
    {
        static void Main()
        {
            Console.WriteLine("please enter the element for search");
            int ele = Convert.ToInt32(Console.ReadLine());

            Search_ele(ele);

        }

        public static void Search_ele(int ele)
        {
            int[][] arr = new int[3][];
            arr[0] = new int[3] { 10, 20, 30 };
            arr[1] = new int[3] { 60, 25, 42 };

            Console.WriteLine("--------------------------");
            Console.WriteLine("Array:");
            for (int i = 0; i < 2; i++)
            {
                foreach (var temp in arr[i])
                {
                    Console.Write("{0}\t", temp);
                }
                Console.WriteLine();
            }

            Console.WriteLine("--------------------------");

            for (int i = 0; i < 2; i++)
            {
                foreach (var temp in arr[i])
                {
                    if (temp == ele)
                    {
                        Console.WriteLine("Entered elemt found:{0}", temp);
                    }
                }
            }

            Console.ReadLine();

        }
    }
}
