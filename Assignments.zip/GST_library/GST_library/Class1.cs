﻿using System;

namespace GST_library
{
    public class GST_Calculation
    {
        double prod_amount;
        double gst_perc;
        double gst_amount;
        double payable_amount;

        //public GST_Calculation(double prod_amount, double gst_perc)
        //{
        //    this.prod_amount = prod_amount;
        //    this.gst_perc = gst_perc;
        //}

        public void Calc_GST(double prod_amount, double gst_perc)
        {
            gst_amount = prod_amount * (gst_perc / 100);

            payable_amount = gst_amount + prod_amount;

            Console.WriteLine($"Applicable GST amount on RS {prod_amount} = {gst_amount}");
            Console.WriteLine($"Total Payable amount = RS {payable_amount}");

        }

       
    }

}
