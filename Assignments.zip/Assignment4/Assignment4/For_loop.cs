﻿using System;

namespace Assignment4
{

    class For_loop
    {
        //Program to display numbers in reverse order from 50 to 1 using for loop
        
        static void Main()
        {
          
            for(int i = 50; i >= 1; i--)
            {
                Console.WriteLine(i);
            }

            Console.ReadLine();
        }
    }
}
