﻿using System;

namespace Assignment4
{
    class Do_while_loop
    {
        //Program to display odd no between 1 to 50 using do while loop
        
        static void Main()
        {
            int i = 1;
            do
            {
                if (!(i % 2 == 0))
                {
                    Console.WriteLine(i);
                }
                i++;
            }
            while (i <= 50);

            Console.ReadLine();
        }
    }
}
