﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class Foreach_odd
    {
        static void Main()
        {
            int[] arr = new int[51];
            for (int i = 1; i <= 50; i++)
            {
                arr[i] = i;
            }

            foreach (int temp in arr)
            {
                if (!(temp % 2 == 0))
                {
                    Console.WriteLine(temp);
                }
            }

            Console.ReadLine();
        }
    }
}
