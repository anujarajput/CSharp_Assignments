﻿using System;
using GST_library;

namespace Assignment9
{
    class Using_GST_library
    {
        static void Main()
        {
            Console.WriteLine("Enter Product Amount");
            double prod_amount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter GST %");
            double gst_perc = Convert.ToDouble(Console.ReadLine());

            GST_Calculation gst_clc = new GST_Calculation();

            gst_clc.Calc_GST(prod_amount, gst_perc);


            Console.ReadLine();
        }
    }
}
