﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    enum City_std_code
    {
     pune=411,mumbai=423,goa=369,delhi=347,banglore=487,hyderabad=398,chennai=400   
    }
}
