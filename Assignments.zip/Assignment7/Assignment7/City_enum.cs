﻿using System;

namespace Assignment7
{
    // enum for CIty name and STD Code
    enum City_std_code
    {
     pune=411,mumbai=423,goa=369,delhi=347,banglore=487,hyderabad=398,chennai=400   
    }
}
