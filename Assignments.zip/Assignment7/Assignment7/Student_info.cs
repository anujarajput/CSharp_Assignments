﻿using System;

namespace Assignment7
{
    struct Student_info
    {
        int roll_no;
        string s_name;
        char s_gender;
        double cont_no;
        
        public Student_info(int roll_no, string s_name, char s_gender, double cont_no)
        {
            this.roll_no = roll_no;
            this.s_name = s_name;
            this.s_gender = s_gender;
            this.cont_no = cont_no;
        }

        public string Display_info()
        {
            if (roll_no > 0 && !(s_name == "") )
            {
                return string.Format($"Student roll no:{roll_no} Student Name:{s_name} Gender:{s_gender} Contact no:{cont_no}");
            }
            else
            {
                return string.Format($"Invalid Student Details format. Please check entred data.");
            }
            
        }
    }
}
