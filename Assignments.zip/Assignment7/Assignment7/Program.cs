﻿using System;

namespace Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
