﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class single_dim_addition
    {

        static void Main()
        {
            Console.WriteLine("How many elements you want to enter in array:");
            int arr_length = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[arr_length];

            Console.WriteLine("Please enter Array elemets :");
            for(int i=0; i<=arr_length-1; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Array entered:");
            for(int i=0; i<arr_length; i++)
            {
                Console.Write("{0}\t",arr[i]);
            }
            Console.WriteLine();

            Console.WriteLine("-----------------------------");
            int sum = 0;
            for(int i=0; i<arr_length; i++)
            {
                sum = sum + arr[i];
            }
            Console.WriteLine("Sum of all Elements in Array:{0}", sum);





            Console.ReadLine();

        }
    }
}
