﻿using System;

namespace Assignment8
{
    class Bank_Transactions
    {
        static void Main()
        {
            Console.WriteLine("Welcome to IBank");
            Console.WriteLine("Please select Account type for transaction(Saving|Current)"); 
            string acc_type = Console.ReadLine();

            //checking type of account
            if(acc_type.ToLowerInvariant() == "saving")
            {
                SavingAccount acc_saving = new SavingAccount();
                acc_saving.Show_Saving_balance();
                
                Console.WriteLine("Please select transaction Process for your Saving account(Deposite|Withdraw)");
                string acc_process = Console.ReadLine();

                //checking transaction process

                if (acc_process.ToLowerInvariant() == "deposite")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_deposite = Convert.ToDouble(Console.ReadLine());
                    
                    acc_saving.Deposit(amount_deposite);

                }
                else if(acc_process.ToLowerInvariant() == "withdraw")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_withdraw = Convert.ToDouble(Console.ReadLine());

                    acc_saving.Withdraw(amount_withdraw);
                }
                else
                {
                    Console.WriteLine("Invalid Transaction choice. Please enter Deposite or Withdraw.");
                }

            }else if(acc_type.ToLowerInvariant() == "current")
            {
                CurrentAccount acc_current = new CurrentAccount();

                acc_current.Show_Current_balance();

                Console.WriteLine("Please select transaction Process for Yor Current Account(Deposite|Withdraw)");
                string acc_process = Console.ReadLine();

                //checking transation process

                if (acc_process.ToLowerInvariant() == "deposite")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_deposite = Convert.ToDouble(Console.ReadLine());
                    
                    acc_current.Deposit(amount_deposite);

                }
                else if (acc_process.ToLowerInvariant() == "withdraw")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_withdraw = Convert.ToDouble(Console.ReadLine());

                    acc_current.Withdraw(amount_withdraw);
                }
                else
                {
                    Console.WriteLine("Invalid Transaction choice. Please enter Deposite or Withdraw.");
                }
                
            }
            else
            {
                Console.WriteLine("Invalid Account choice. Please select Current or saving.");
            }

            Console.ReadLine();
        }
    }
}
