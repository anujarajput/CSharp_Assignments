﻿using System;

namespace Assignment8
{
    class Hotel_room
    {
        private int r_number;
        private int r_floor;
        private string r_type;
        private int r_capacity;
        private DateTime r_bookedTime;
        private double r_price;

        //parameterized constructor
        public Hotel_room(int r_number, int r_floor, string r_type, int r_capacity, DateTime r_bookedTime, double r_price)
        {
            this.r_number = r_number;
            this.r_floor = r_floor;
            this.r_type = r_type;
            this.r_capacity = r_capacity;
            this.r_bookedTime = r_bookedTime;
            this.r_price = r_price;
        }

        public int Room_number
        {
            get
            {
                return r_number;
            }

            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Invalid Room no");
                }
                else
                {
                    r_number = value;
                }

            }
        }

        public int Room_floor
        {
            get
            {
                return r_floor;
            }

            set
            {
                    r_floor = value;
            }
        }

        public string Room_type
        {
            get
            {
                return r_type;
            }

            set
            {
                if (value == "ac")
                {
                    r_type = "AC Room";
                }
                else
                {
                    r_type = "Non-AC room";
                }
            }
        }

        public int Room_capacity
        {
            get
            {
                return r_capacity;
            }

            set
            {
                    r_capacity = value;
            }
        }
        public DateTime Room_bookingTime
        {
            get
            {
                return r_bookedTime;
            }

            set
            {
                r_bookedTime = value;
            }
        }

        public double Room_price
        {
            get
            {
                return r_price;
            }

            set
            {
                r_price = value;
            }
        }
        /// <summary>
        /// Overriding ToString method
        /// </summary>
        public override string ToString()
        {
            return $"Room Booking Details \nRoom No:{Room_number} | Floor No:{Room_floor} | Room Type:{Room_type} | Room Capacity:{Room_capacity} | CheckIn Date: {r_bookedTime} | Room Charges(per Day):{Room_price}";
        }
    }

    class Hotel_main
    {
        static void Main()
        {
            //Taking all Room booking data from users
            Console.WriteLine("Enter Hotel Room No:");
            int Room_number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Floor no:");
            int Room_floor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room type");
            string Room_type = Console.ReadLine();

            Console.WriteLine("Enter no of Peope:");
            int Room_capacity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Checkin Date:");
            DateTime Room_bookingTime = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Price for room");
            Double Room_price = Convert.ToDouble(Console.ReadLine());

            Hotel_room hotel1 = new Hotel_room(Room_number, Room_floor, Room_type, Room_capacity, Room_bookingTime, Room_price);

            Console.WriteLine(hotel1);
            
            Console.ReadLine();
        }
    }

}
