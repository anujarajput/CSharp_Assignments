﻿using System;
namespace Assignment8
{
    //Declaring Interface

    interface IBankAccount
    {
        void Deposit(double amount);
        void Withdraw(double amount);
    }
}
