﻿using System;

namespace Assignment8
{
    //Saving account Section

    class SavingAccount:IBankAccount
    {
        double acc_avilable_balance = 36539; //User saving account balance
        
        /// <summary>
        /// Performing Deposite transaction
        /// </summary>
        public void Deposit(double amount)
        {
            Console.WriteLine($"Your current Transaction is succesful. Rs. {amount} is succesfully Deposited.");
            acc_avilable_balance = acc_avilable_balance + amount;
            Show_Saving_balance();
        }

        /// <summary>
        /// Performing withdraw Transaction
        /// </summary>
        public void Withdraw(double amount)
        {
            if(amount < acc_avilable_balance)
            {
                Console.WriteLine($"Your current Transaction is succesful. Rs. {amount} is succesfully Withdrawed.");
                acc_avilable_balance = acc_avilable_balance - amount;
                Show_Saving_balance();
            }
            else
            {
                Console.WriteLine("Insufficient Balance.");
                Show_Saving_balance();
            }
            
        }

        /// <summary>
        /// Displaying account balance after successfull transaction
        /// </summary>
        public void Show_Saving_balance()
        {
            Console.WriteLine($"Yor Saving account Balance: RS {acc_avilable_balance}");
        }

    }

}
