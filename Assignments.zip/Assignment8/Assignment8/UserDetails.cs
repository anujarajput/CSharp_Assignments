﻿using System;

namespace Assignment8
{
    class UserDetails
    {
        private long id;
        private string name;
        private string email;
        private string dob;

        public UserDetails(long id, string name, string email, string dob)
        {
            this.id = id;
            this.name = name;
            this.email = email;
            this.dob = dob;
        }

        public long u_id {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string u_name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string u_email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string u_dob
        {
            get
            {
                return dob;
            }

            set
            {
                dob = value;
            }
        }

        public override string ToString()
        {
            return $"Registration Details\n User ID: {u_id} | User Name: {u_name} | User Mail: {u_email} | Date of Birth: {u_dob}";
        }

    }

    class UserRegistration
    {
        static void Main()
        {
            Console.WriteLine("Enter user ID:");
            int u_id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter User Name:");
            string u_name = Console.ReadLine();

            Console.WriteLine("Enter Email address");
            string u_email = Console.ReadLine();

            Console.WriteLine("Enter Date of birth");
            string u_dob = Console.ReadLine();

            UserDetails uDetails = new UserDetails(u_id, u_name, u_email, u_dob);
            Console.WriteLine($"User Details:\n {uDetails}");

            Console.ReadLine();
            
        }
    }
}
